Program: DummingDummy
Version: 1.0
Operating System:  Windows
Release Date: 12/14/2005
Author:  Xangis
License:  Totally free
Download Location:  www.xangis.com
Installation:  Unzip anywhere convenient.
Use:  Run the program.  You can play any of the four included drum sounds
      by either clicking the button or hitting the key indicated on the
      button.  To exit, hit escape or click exit.

      For the adventurous, you can replace the included .wav sounds with
      any .wav file, as long as you use the same name.